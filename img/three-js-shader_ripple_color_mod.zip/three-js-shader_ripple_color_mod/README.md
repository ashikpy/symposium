# [Three.js]shader_ripple_color_mod()

A Pen created on CodePen.io. Original URL: [https://codepen.io/ma_suwa/pen/NWePWdo](https://codepen.io/ma_suwa/pen/NWePWdo).

