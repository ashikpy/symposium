# Canva's Magic Mouse Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/Hyperplexed/pen/OJdpEME](https://codepen.io/Hyperplexed/pen/OJdpEME).

4 min Tutorial: https://youtu.be/G9207EJySaA